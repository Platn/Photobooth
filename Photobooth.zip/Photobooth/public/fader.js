/* called when image is clicked */
function getDLabels(imgName, labelId) {
        // construct url for query
	var url = "http://138.68.25.50:11751/query?img=" + imgName;
        // becomes method of request object oReq
	function reqListener() {
  	    var pgh = document.getElementById(labelId);
        var stringSplit = this.responseText.split(',');
        
        for(i = 0; i < stringSplit.length; i++)
            {
                var divBox = document.createElement("div");
                divBox.className = "labelItem";
                
                var deleteLabelImage = document.createElement("img");
                deleteLabelImage.src = "./removeTagButton.png";
                deleteLabelImage.id = "removeLabel";
                
                var newLabel = document.createTextNode(stringSplit[i]);
                newLabel.id = "labelProperty";
                
                divBox.appendChild(deleteLabelImage);
                divBox.appendChild(newLabel);
                pgh.appendChild(divBox);
            }
	}
    
    // Server stuff here
    
	var oReq = new XMLHttpRequest();
	oReq.addEventListener("load", reqListener);
	oReq.open("GET", url); // Type Of Request, Who we request from
    // Get is the app.get, it will use that to call on it
    // URL is a string we create
	oReq.send();
}

function getLabels(imgName,labelId)
{
    var url = "http://138.68.25.50:11751/query?img=" + imgName + '.jpg&op=obtain';
    
    alert(url);
        // becomes method of request object oReq
	function reqListener() {
        var pgh = document.getElementById(labelId);
  	    var stringSplit = this.responseText.split(',');
        
        for(i = 0; i < stringSplit.length; i++)
            {
                var divBox = document.createElement("div");
                divBox.className = "labelItem";
                
                var deleteLabelImage = document.createElement("img");
                deleteLabelImage.src = "./removeTagButton.png";
                deleteLabelImage.id = "removeLabel";
                
                var newLabel = document.createTextNode(stringSplit[i]);
                newLabel.id = "labelProperty";
                
                divBox.appendChild(deleteLabelImage);
                divBox.appendChild(newLabel);
                pgh.appendChild(divBox);
            }
    }
    
    var oReq = new XMLHttpRequest();
	oReq.addEventListener("load", reqListener);
	oReq.open("GET", url); // Type Of Request, Who we request from
    // Get is the app.get, it will use that to call on it
    // URL is a string we create
	oReq.send();
}

function addLabels()
{
    
}

function uploadFile() {
    var url = "http://138.68.25.50:11751";

    // where we find the file handle
    var selectedFile = document.getElementById('fileSelector').files[0];
    var formData = new FormData(); 
    // stick the file into the form
    formData.append("userfile", selectedFile);

    // more or less a standard http request
    var oReq = new XMLHttpRequest();
    // POST requests contain data in the body
    // the "true" is the default for the third param, so 
    // it is often omitted; it means do the upload 
    // asynchornously, that is, using a callback instead
    // of blocking until the operation is completed. 
    oReq.open("POST", url, true);  
    oReq.onload = function() {
	// the response, in case we want to look at it
	console.log(oReq.responseText);
    }
    oReq.send(formData);
}


function readFile() {
    var selectedFile = document.getElementById('fileSelector').files[0];
    var image = document.getElementById('theImage');

    var fr = new FileReader();
    // anonymous callback uses file as image source
    fr.onload = function () {
	image.src = fr.result;
    };
    fr.readAsDataURL(selectedFile);    // begin reading
}



function clicked() // Test function
{
    window.location.href = "http://138.68.25.50:11751/weatherApp.html";
}

function clickedUpload()
{
    var selectedFile = document.getElementById('fileSelector').files[0];
    var image = document.getElementById('uploadBar');

    var fr = new FileReader();
    // anonymous callback uses file as image source
    fr.onload = function () {
	image.src = fr.result;
    };
    fr.readAsDataURL(selectedFile);    // begin reading
}


function clickedFavorites()
{
    window.alert("Favorite clicked");
}

/* submitSearch(e) will take in an event e, thne it will check if it is the enter key
** once the enter key has been pressed, it will search for the value, ** not implemented **
*/

function submitSearch(e)
{
    if (e.keyCode == 13) {
    
        window.alert("Enter Pressed");
        var text = document.getElementById("searchBox").value;
        window.alert(text);
        return false;
    }
}

/* changeFileName() will set the fileName to a blank, it will then grab the filename of fileSelector
** and set it to that specific one. Afterwards it will send the text without the fake path and append
*/

function selectFileName() 
{
    var fileName = document.getElementById("fileName");
    
    var file = document.getElementById('fileSelector');
    var extract = document.createTextNode(file.value);
    var sendText = document.createTextNode(extract.textContent.replace("C:\\fakepath\\",""));
    if(sendText.nodeValue == "")
    {
        fileName.innerHTML = "No file selected";
        return;
    }
    
    fileName.innerHTML = "";
    fileName.appendChild(sendText);
}

/* LoadItem() will grab the name of the file from FileSelector
** then it will create an element of image type and append it to the upload section 
*/

function Counter(){
    Counter.counter++;
    alert(Counter.counter);
    
    function returnCounter(){
        return Counter.counter;
    }
}

Counter.counter = 0;

function loadItem() // We can probably have a div that appends and then inside of that div do another append
{
//    var incrementCounter = new Counter();
    if(uploadItems.childElementCount > 11)
    {
            alert("No more items can be appended. Please finish processing your photos.");
            return;
    }
    
    var selectedFile = document.getElementById('fileSelector').files[0];
    uploadFile();
    
    /* These lines up until textParse are used to get just the eagle part */
    var file = document.getElementById('fileSelector');
    var extract = document.createTextNode(file.value);
    var sendText = document.createTextNode(extract.textContent.replace("C:\\fakepath\\",""));
    var textParse = document.createTextNode(sendText.textContent.replace(".jpg", ""));
    
    if(sendText.nodeValue == "")
    {
        fileName.innerHTML = "No file selected";
        return;
    }
    
    var fr = new FileReader(); // anonymous callback uses file as image source
    fr.onload = function () {
        
        // First check to see that we have enough space per file.
        
        
        /* Create an image and labelbox and store it inside of a box */
        var imgDiv = document.createElement("div");
        var img = document.createElement("img");   
        var labelBox = document.createElement("div");
        
        
        imgDiv.id = "imageContainer";
        img.id = "uploadImage";
        img.src = fr.result;
        labelBox.id = textParse.textContent;
        labelBox.className = "labelType";
//        labelBox.id = textParse.textContent;
//        labelBox.id = ; Need something for id?
        
        getLabels(textParse.textContent, labelBox.id);
        
        
        
        fadeImage(img); // Fader for image
        
        // Upload the item+label into the container and the container onto the webpage
        
        imgDiv.appendChild(img);
        imgDiv.appendChild(labelBox);
        uploadItems.appendChild(imgDiv);
    };
    
    fr.readAsDataURL(selectedFile);    // begin reading
    
    /* Down here is where we need to call on the server and then it will send it back over the signals. 
    ** We call on the unfade part here.
    ** So now we just need the server functionality.
    */
}

/* fadeImage() will fade out the image passed in, it sets opacity downward.
** Function may require further implementation for timer with server
*/

function fadeImage(img) // Uncomment the lines below for original function
{
//    var image = document.getElementById('img');
//    var button = document.getElementById('fadeButton');
//    
//    
//    
//    if (button.textContent == 'Fade') 
//    {
//	   image.style.opacity = 0.5;
//	   button.textContent = 'UnFade';
//    } 
//    
//    else 
//    {
//	   image.style.opacity = 1.0;
//	   button.textContent = 'Fade';
//    }
    
    img.style.opacity = 0.5; // This is all that's required to fade
}

/* unFadeImage() will take in an image and change its opacity upward. 
** Function may require further implementation for timer with server
*/

function unFadeImage(img) // Pass in the image that needs to be unfaded
{
    img.style.opacity = 1.0;
}

/* focusBox() will activate upon search bar being clicked and drop into the search
**
*/

function focusBox()
{
    document.getElementById("searchBox").focus();
}